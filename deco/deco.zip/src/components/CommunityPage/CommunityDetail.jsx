import React from 'react'

const CommunityDetail = () => {
  return (
    <div>CommunityDetail</div>
  )
}

export default CommunityDetail;