import { atom, selector } from "recoil";

export const contentState = atom({
  key: "contentState",
  default: "",
});
