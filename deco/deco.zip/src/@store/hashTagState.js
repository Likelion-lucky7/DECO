import { atom, selector } from "recoil";

export const hashTagState = atom({
  key: "hashTagState",
  default: "",
});
