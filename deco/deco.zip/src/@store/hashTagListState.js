import { atom, selector } from "recoil";

export const hashTagListState = atom({
  key: "hashTagListState",
  default: [],
});
