import SideProjectList from '@/components/SideProjectPage/SideProjectList';
import React from 'react'

const SideProjectPage = () => {
  return (
    <SideProjectList />
  )
}

export default SideProjectPage;