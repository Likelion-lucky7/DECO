import CommunityList from '@/components/CommunityPage/CommunityList';
import React from 'react'

const CommunityPage = () => {
  return (
    <CommunityList />
  )
}

export default CommunityPage;