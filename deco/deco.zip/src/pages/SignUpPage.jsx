import SignUp from "@/components/SignUpPage/SignUp";
import React from "react";

const SignUpPage = () => {
  return <SignUp />;
};

export default SignUpPage;
