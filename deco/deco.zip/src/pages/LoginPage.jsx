import Login from '@/components/LoginPage/Login';
import React from 'react'

const LoginPage = () => {
  return (
    <Login />
  )
}

export default LoginPage;