import QuestionList from '@/components/QuestionPage/QuestionList';
import React from 'react'

const QuestionPage = () => {
  return (
    <QuestionList />
  )
}

export default QuestionPage;